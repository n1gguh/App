import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ====== CONFIG ======
const int kStepsGoal = 10000;
const double kWaterGoalLiters = 3.0;
const double kProteinPerKg = 1.5;

// ====== MODELS ======
class Exercise {
  final String name;
  final String details; // e.g., "20 min" or "3x12"
  Exercise({required this.name, required this.details});

  Map<String, dynamic> toJson() => {"name": name, "details": details};

  factory Exercise.fromJson(Map<String, dynamic> j) =>
      Exercise(name: j["name"] ?? "", details: j["details"] ?? "");
}

class DayData {
  int steps;
  double waterLiters;
  double proteinGrams;
  List<Exercise> exercises;

  DayData({
    required this.steps,
    required this.waterLiters,
    required this.proteinGrams,
    required this.exercises,
  });

  Map<String, dynamic> toJson() => {
        "steps": steps,
        "waterLiters": waterLiters,
        "proteinGrams": proteinGrams,
        "exercises": exercises.map((e) => e.toJson()).toList(),
      };

  factory DayData.fromJson(Map<String, dynamic> j) => DayData(
        steps: (j["steps"] ?? 0) as int,
        waterLiters: (j["waterLiters"] ?? 0.0).toDouble(),
        proteinGrams: (j["proteinGrams"] ?? 0.0).toDouble(),
        exercises: (j["exercises"] as List? ?? [])
            .map((e) => Exercise.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
      );
}

// ====== STORAGE ======
class Storage {
  static const String keyWeight = "weightKg";

  static String keyForDate(DateTime date) {
    final d = DateFormat('yyyy-MM-dd').format(date);
    return "daydata_$d";
  }

  static Future<double> loadWeight() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getDouble(keyWeight) ?? 60.0;
  }

  static Future<void> saveWeight(double kg) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(keyWeight, kg);
  }

  static Future<DayData> loadDay(DateTime date) async {
    final prefs = await SharedPreferences.getInstance();
    final key = keyForDate(date);
    final raw = prefs.getString(key);
    if (raw == null) {
      return DayData(steps: 0, waterLiters: 0, proteinGrams: 0, exercises: []);
    }
    try {
      final j = jsonDecode(raw);
      return DayData.fromJson(Map<String, dynamic>.from(j));
    } catch (_) {
      return DayData(steps: 0, waterLiters: 0, proteinGrams: 0, exercises: []);
    }
  }

  static Future<void> saveDay(DateTime date, DayData data) async {
    final prefs = await SharedPreferences.getInstance();
    final key = keyForDate(date);
    await prefs.setString(key, jsonEncode(data.toJson()));
  }
}

// ====== HELPERS ======
bool goalsMet(DayData d, double weightKg) {
  final proteinGoal = (kProteinPerKg * weightKg);
  return d.steps >= kStepsGoal &&
      d.waterLiters >= kWaterGoalLiters &&
      d.proteinGrams >= proteinGoal;
}

Future<int> computeStreak(double weightKg) async {
  int streak = 0;
  DateTime cursor = DateTime.now();
  // Remove time part
  cursor = DateTime(cursor.year, cursor.month, cursor.day);
  for (int i = 0; i < 365; i++) {
    final day = await Storage.loadDay(cursor);
    if (goalsMet(day, weightKg)) {
      streak += 1;
      cursor = cursor.subtract(const Duration(days: 1));
    } else {
      break;
    }
  }
  return streak;
}

// ====== APP ======
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const FitnessApp());
}

class FitnessApp extends StatelessWidget {
  const FitnessApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Fitness Streak',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;
  double _weightKg = 60.0;
  DayData _today = DayData(steps: 0, waterLiters: 0, proteinGrams: 0, exercises: []);
  int _streak = 0;
  DateTime _todayDate = DateTime.now();

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final weight = await Storage.loadWeight();
    final todayDate = DateTime.now();
    final normalized = DateTime(todayDate.year, todayDate.month, todayDate.day);
    final data = await Storage.loadDay(normalized);
    final s = await computeStreak(weight);
    setState(() {
      _weightKg = weight;
      _today = data;
      _streak = s;
      _todayDate = normalized;
    });
  }

  Future<void> _saveToday() async {
    await Storage.saveDay(_todayDate, _today);
    final s = await computeStreak(_weightKg);
    setState(() {
      _streak = s;
    });
  }

  void _addSteps(int amount) {
    setState(() {
      _today.steps = (_today.steps + amount).clamp(0, 1000000);
    });
    _saveToday();
  }

  void _addWater(double liters) {
    setState(() {
      _today.waterLiters = (_today.waterLiters + liters).clamp(0.0, 1000.0);
    });
    _saveToday();
  }

  void _addProtein(double grams) {
    setState(() {
      _today.proteinGrams = (_today.proteinGrams + grams).clamp(0.0, 100000.0);
    });
    _saveToday();
  }

  void _addExercise(String name, String details) {
    setState(() {
      _today.exercises = [..._today.exercises, Exercise(name: name, details: details)];
    });
    _saveToday();
  }

  void _removeExercise(int index) {
    setState(() {
      _today.exercises = List.of(_today.exercises)..removeAt(index);
    });
    _saveToday();
  }

  @override
  Widget build(BuildContext context) {
    final proteinGoal = (kProteinPerKg * _weightKg);
    final dateLabel = DateFormat('EEE, MMM d').format(_todayDate);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Fitness Streak'),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 8.0),
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.orange.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(24),
                ),
                child: Text('🔥 Streak: $_streak'),
              ),
            ),
          )
        ],
      ),
      body: SafeArea(
        child: IndexedStack(
          index: _tab,
          children: [
            _buildTodayTab(context, proteinGoal, dateLabel),
            _buildHistoryTab(context),
            _buildSettingsTab(context),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.today_outlined), label: "Today"),
          NavigationDestination(icon: Icon(Icons.timeline_outlined), label: "History"),
          NavigationDestination(icon: Icon(Icons.settings_outlined), label: "Settings"),
        ],
      ),
    );
  }

  Widget _buildTodayTab(BuildContext context, double proteinGoal, String dateLabel) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(dateLabel, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 12),
          _GoalCard(
            title: "Steps",
            valueText: "${_today.steps} / $kStepsGoal",
            progress: (_today.steps / kStepsGoal).clamp(0.0, 1.0),
            child: Wrap(
              spacing: 8,
              children: [
                _IncButton(label: "+100", onTap: () => _addSteps(100)),
                _IncButton(label: "+500", onTap: () => _addSteps(500)),
                _IncButton(label: "+1000", onTap: () => _addSteps(1000)),
                _QuickEditButton(
                  hint: "Add custom",
                  onConfirm: (v) {
                    final n = int.tryParse(v.trim()) ?? 0;
                    if (n != 0) _addSteps(n);
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _GoalCard(
            title: "Water (L)",
            valueText: "${_today.waterLiters.toStringAsFixed(2)} / ${kWaterGoalLiters.toStringAsFixed(2)}",
            progress: (_today.waterLiters / kWaterGoalLiters).clamp(0.0, 1.0),
            child: Wrap(
              spacing: 8,
              children: [
                _IncButton(label: "+0.25L", onTap: () => _addWater(0.25)),
                _IncButton(label: "+0.5L", onTap: () => _addWater(0.5)),
                _IncButton(label: "+1.0L", onTap: () => _addWater(1.0)),
                _QuickEditButton(
                  hint: "Add liters",
                  onConfirm: (v) {
                    final d = double.tryParse(v.trim()) ?? 0.0;
                    if (d != 0.0) _addWater(d);
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _GoalCard(
            title: "Protein (g)",
            valueText: "${_today.proteinGrams.toStringAsFixed(0)} / ${proteinGoal.toStringAsFixed(0)}",
            progress: (_today.proteinGrams / proteinGoal).clamp(0.0, 1.0),
            child: Wrap(
              spacing: 8,
              children: [
                _IncButton(label: "+10g", onTap: () => _addProtein(10)),
                _IncButton(label: "+20g", onTap: () => _addProtein(20)),
                _IncButton(label: "+40g", onTap: () => _addProtein(40)),
                _QuickEditButton(
                  hint: "Add grams",
                  onConfirm: (v) {
                    final d = double.tryParse(v.trim()) ?? 0.0;
                    if (d != 0.0) _addProtein(d);
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _ExercisesCard(
            exercises: _today.exercises,
            onAdd: _addExercise,
            onDelete: _removeExercise,
          ),
          const SizedBox(height: 24),
          _SummaryBanner(
            stepsOk: _today.steps >= kStepsGoal,
            waterOk: _today.waterLiters >= kWaterGoalLiters,
            proteinOk: _today.proteinGrams >= proteinGoal,
          ),
        ],
      ),
    );
  }

  Widget _buildHistoryTab(BuildContext context) {
    // Show the last 7 days quick glance
    final itemsFuture = () async {
      final weight = _weightKg;
      final List<_HistoryItem> items = [];
      DateTime cursor = DateTime.now();
      cursor = DateTime(cursor.year, cursor.month, cursor.day);
      for (int i = 0; i < 7; i++) {
        final d = await Storage.loadDay(cursor);
        items.add(_HistoryItem(
          date: cursor,
          steps: d.steps,
          water: d.waterLiters,
          protein: d.proteinGrams,
          ok: goalsMet(d, weight),
        ));
        cursor = cursor.subtract(const Duration(days: 1));
      }
      return items;
    }();

    return FutureBuilder<List<_HistoryItem>>(
      future: itemsFuture,
      builder: (context, snap) {
        if (!snap.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final items = snap.data!;
        return ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: items.length,
          separatorBuilder: (_, __) => const SizedBox(height: 8),
          itemBuilder: (context, i) {
            final it = items[i];
            final d = DateFormat('EEE, MMM d').format(it.date);
            return Card(
              elevation: 0,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              child: ListTile(
                leading: Icon(it.ok ? Icons.check_circle : Icons.cancel, color: it.ok ? Colors.green : Colors.red),
                title: Text(d),
                subtitle: Text("Steps: ${it.steps} • Water: ${it.water.toStringAsFixed(2)}L • Protein: ${it.protein.toStringAsFixed(0)}g"),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildSettingsTab(BuildContext context) {
    final controller = TextEditingController(text: _weightKg.toStringAsFixed(1));
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Your weight (kg)", style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: controller,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: "e.g., 60.0",
                  ),
                ),
              ),
              const SizedBox(width: 8),
              ElevatedButton(
                onPressed: () async {
                  final v = double.tryParse(controller.text.trim());
                  if (v != null && v > 0 && v < 600) {
                    await Storage.saveWeight(v);
                    final s = await computeStreak(v);
                    setState(() {
                      _weightKg = v;
                      _streak = s;
                    });
                    if (mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Weight updated")),
                      );
                    }
                  }
                },
                child: const Text("Save"),
              ),
            ],
          ),
          const SizedBox(height: 24),
          Text(
            "Protein goal = 1.5 × weight. With your weight, your goal is ${(kProteinPerKg * _weightKg).toStringAsFixed(0)} g/day.",
          ),
          const SizedBox(height: 24),
          Text("About", style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          const Text("This app stores your data locally on the device using SharedPreferences."),
        ],
      ),
    );
  }
}

class _HistoryItem {
  final DateTime date;
  final int steps;
  final double water;
  final double protein;
  final bool ok;
  _HistoryItem({required this.date, required this.steps, required this.water, required this.protein, required this.ok});
}

// ====== UI WIDGETS ======
class _GoalCard extends StatelessWidget {
  final String title;
  final String valueText;
  final double progress;
  final Widget child;
  const _GoalCard({required this.title, required this.valueText, required this.progress, required this.child});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(title, style: Theme.of(context).textTheme.titleMedium),
                Text(valueText, style: Theme.of(context).textTheme.titleSmall),
              ],
            ),
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(value: progress),
            ),
            const SizedBox(height: 12),
            child,
          ],
        ),
      ),
    );
  }
}

class _IncButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _IncButton({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(onPressed: onTap, child: Text(label));
  }
}

class _QuickEditButton extends StatelessWidget {
  final String hint;
  final void Function(String value) onConfirm;
  const _QuickEditButton({required this.hint, required this.onConfirm});

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      onPressed: () async {
        final controller = TextEditingController();
        final v = await showDialog<String>(
          context: context,
          builder: (context) => AlertDialog(
            title: Text(hint),
            content: TextField(
              controller: controller,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(hintText: hint),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context), child: const Text("Cancel")),
              ElevatedButton(onPressed: () => Navigator.pop(context, controller.text), child: const Text("Add")),
            ],
          ),
        );
        if (v != null && v.trim().isNotEmpty) {
          onConfirm(v);
        }
      },
      child: const Text("Custom"),
    );
  }
}

class _ExercisesCard extends StatelessWidget {
  final List<Exercise> exercises;
  final void Function(String name, String details) onAdd;
  final void Function(int index) onDelete;
  const _ExercisesCard({required this.exercises, required this.onAdd, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("Exercises", style: Theme.of(context).textTheme.titleMedium),
                TextButton.icon(
                  onPressed: () async {
                    final nameController = TextEditingController();
                    final detailsController = TextEditingController();
                    final res = await showDialog<bool>(
                      context: context,
                      builder: (context) => AlertDialog(
                        title: const Text("Add exercise"),
                        content: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            TextField(
                              controller: nameController,
                              decoration: const InputDecoration(labelText: "Name (e.g., Push-ups)"),
                            ),
                            TextField(
                              controller: detailsController,
                              decoration: const InputDecoration(labelText: "Details (e.g., 3x12 or 20 min)"),
                            ),
                          ],
                        ),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text("Cancel")),
                          ElevatedButton(onPressed: () => Navigator.pop(context, true), child: const Text("Add")),
                        ],
                      ),
                    );
                    if (res == true) {
                      final name = nameController.text.trim();
                      final det = detailsController.text.trim();
                      if (name.isNotEmpty) {
                        onAdd(name, det);
                      }
                    }
                  },
                  icon: const Icon(Icons.add),
                  label: const Text("Add"),
                ),
              ],
            ),
            const SizedBox(height: 8),
            if (exercises.isEmpty)
              const Text("No exercises yet. Tap Add to log one."),
            if (exercises.isNotEmpty)
              ...List.generate(exercises.length, (i) {
                final e = exercises[i];
                return Dismissible(
                  key: ValueKey("${e.name}-$i"),
                  direction: DismissDirection.endToStart,
                  background: Container(
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    color: Colors.red.withOpacity(0.1),
                    child: const Icon(Icons.delete),
                  ),
                  onDismissed: (_) => onDelete(i),
                  child: ListTile(
                    title: Text(e.name),
                    subtitle: Text(e.details.isEmpty ? " " : e.details),
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }
}

class _SummaryBanner extends StatelessWidget {
  final bool stepsOk;
  final bool waterOk;
  final bool proteinOk;
  const _SummaryBanner({required this.stepsOk, required this.waterOk, required this.proteinOk});

  @override
  Widget build(BuildContext context) {
    final allOk = stepsOk && waterOk && proteinOk;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: allOk ? Colors.green.withOpacity(0.12) : Colors.orange.withOpacity(0.12),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Icon(allOk ? Icons.verified : Icons.info_outline),
          const SizedBox(width: 12),
          Expanded(
            child: Text(allOk
                ? "Great! You met all goals today. Keep the streak going!"
                : "Keep going! Meet all three goals to grow your streak."),
          ),
        ],
      ),
    );
  }
}
